package com.example.hdc_user.testinternalfile;


        import android.app.Activity;
        import android.content.Context;
        import android.support.v7.app.AppCompatActivity;
        import android.os.Bundle;
        import android.view.Menu;
        import android.view.MenuItem;
        import android.view.View;
        import android.widget.EditText;
        import android.widget.RadioGroup;
        import android.widget.TextView;
        import android.widget.Toast;

        import java.io.File;
        import java.io.FileInputStream;
        import java.io.FileOutputStream;

public class MainActivity extends Activity {

    @Override

        protected void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            setContentView(R.layout.activity_main);
        }
            public void deleteFile(View view){
                Context context = view.getContext();
                EditText ed = (EditText) findViewById(R.id.fileNameEditText);
                String filename = ed.getText().toString();
                context.deleteFile(filename);
                Toast.makeText(this, "File is deleted" , Toast.LENGTH_SHORT).show();
                return;
            }
            public void createFile(View view){
                Context context = view.getContext();
                EditText ed = (EditText) findViewById(R.id.fileNameEditText);
                String filename = ed.getText().toString();

                if (filename.isEmpty()) {
                    Toast.makeText(this, "No filename is given", Toast.LENGTH_SHORT).show();
                    return;
                }

                File file = new File(context.getFilesDir(), filename);

                try {
                    if (!file.exists()) {
                        EditText filecontented = (EditText) findViewById(R.id.fileContentEditText);
                       String filecontentst = filecontented.getText().toString();
                      TextView filecontentview = (TextView) findViewById(R.id.fileContentView);
                       String filecontentviewst = filecontentview.getText().toString();

                        FileOutputStream outputStream;

                        try {
                            outputStream = openFileOutput(filename, Context.MODE_PRIVATE);


                           outputStream.write(filecontentst.getBytes());

                            outputStream.close();
                        } catch (Exception e) {
                            e.printStackTrace();
                        }

                        Toast.makeText(this, "File created!", Toast.LENGTH_SHORT).show();

                        filecontentview.setText(filecontentst);

                        return;
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }

                return;

                        }

                public void loadFile (View view){
                    Context context = view.getContext();
                    EditText ed = (EditText) findViewById(R.id.fileNameEditText);
                    String filename = ed.getText().toString();
                    if (filename.isEmpty()) {
                        Toast.makeText(this, "No filename is given", Toast.LENGTH_SHORT).show();
                        return;
                    }

                    File file = new File(context.getFilesDir(), filename);
                    try {
                        if (!file.exists()) {
                            Toast.makeText(this, "File does not exist!", Toast.LENGTH_SHORT).show();
                            return;
                        }
                    } catch (Exception e) {
                        e.printStackTrace();
                    }


                    FileInputStream inputStream;
                    long size = file.length();
                    byte inpstream[] = new byte[(int) size];

                    try {
                        inputStream = openFileInput(filename);
                        inputStream.read(inpstream);
                        inputStream.close();
                    } catch (Exception e) {
                        e.printStackTrace();
                    }

                    Toast.makeText(this, "Load succeed...", Toast.LENGTH_SHORT).show();
                    TextView filecontentview = (TextView) findViewById(R.id.fileContentView);
                    String tv = new String(inpstream);
                    filecontentview.setText(tv);

                    EditText filecontented = (EditText) findViewById(R.id.fileContentEditText);
                    filecontented.setText("");
                }

                public void saveFile (View view){
                    Context context = view.getContext();
                    EditText ed = (EditText) findViewById(R.id.fileNameEditText);
                    String filename = ed.getText().toString();

                    if (filename.isEmpty()) {
                        Toast.makeText(this, "No filename is given", Toast.LENGTH_SHORT).show();
                        return;
                    }

                    File file = new File(context.getFilesDir(), filename);

                    try {
                        if (!file.exists()) {
                            Toast.makeText(this, "File does not exist!", Toast.LENGTH_SHORT).show();
                            return;
                        }
                    } catch (Exception e) {
                        e.printStackTrace();
                    }

                    EditText filecontented = (EditText) findViewById(R.id.fileContentEditText);
                    String filecontentst = filecontented.getText().toString();
                    TextView filecontentview = (TextView) findViewById(R.id.fileContentView);
                    String filecontentviewst = filecontentview.getText().toString();

                    FileOutputStream outputStream;
                    RadioGroup rbt_group = (RadioGroup) findViewById(R.id.fileSaveRadioGroup);

                    try {
                        outputStream = openFileOutput(filename, Context.MODE_PRIVATE);

                        if (rbt_group.getCheckedRadioButtonId() == R.id.fileContentInsertion) {
                            outputStream.write(filecontentviewst.getBytes());
                        }

                        outputStream.write(filecontentst.getBytes());
                        outputStream.close();
                    } catch (Exception e) {
                        e.printStackTrace();
                    }

                    Toast.makeText(this, "File updated!", Toast.LENGTH_SHORT).show();

                    if (rbt_group.getCheckedRadioButtonId() == R.id.fileContentInsertion) {
                        filecontentview.setText(filecontentviewst + filecontentst);
                    } else filecontentview.setText(filecontentst);

                    return;
                }
            }



