package com.example.user.intentfilterexample2;

import android.app.Activity;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Intent intent = getIntent();

        setContentView(R.layout.activity_main);
        if (intent != null && intent.getAction() == "com.example.user.intentfilterexample1.MainActivity") {
            TextView number1 = (TextView) (findViewById(R.id.number1_textView));
            TextView number2 = (TextView) (findViewById(R.id.number2_textView));

            if (number1 == null) {
                Toast.makeText(getBaseContext(), "number1 is null", Toast.LENGTH_SHORT).show();
                return;
            }
            number1.setText(intent.getExtras().getString("number1"));
            number2.setText(intent.getExtras().getString("number2"));

            int n1 = Integer.parseInt(intent.getExtras().getString("number1"));
            int n2 = Integer.parseInt(intent.getExtras().getString("number2"));

            int sum = n1 + n2;
            TextView sumView = (TextView) findViewById(R.id.sum_textView);
            String resultString = Integer.toString(sum);
            sumView.setText(resultString);

        }
    }
        public void onClick(View v){

        Intent intent = getIntent();
        TextView sumview = (TextView)findViewById(R.id.sum_textView);
        intent.putExtra("sum", sumview.getText().toString());
        setResult(Activity.RESULT_OK, intent);
        finish();
    }

}
