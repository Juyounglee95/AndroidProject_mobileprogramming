package com.example.user.databaseexample;

import android.view.View;
import android.widget.EditText;

class DialogWrapper {
    EditText titleField=null;
    EditText valueField=null;
    View base =null;

    DialogWrapper(View base){
        this. base=base;
        valueField=(EditText)base.findViewById(R.id.value);
    }
    String getTitle(){return getTitleField().getText().toString();}
    float getValue(){ return Float.valueOf(getValueField().getText().toString());}

    private EditText getTitleField(){
        if(titleField==null){
            titleField = (EditText)base.findViewById(R.id.title);
        }
        return titleField;
    }
    private EditText getValueField(){
        if(valueField==null){
            valueField=(EditText)base.findViewById(R.id.value);
        }
        return valueField;
    }

}