package com.example.user.databaseexample;

import android.view.View;
import android.widget.AdapterView;
import android.widget.EditText;
import android.widget.RadioGroup;
import android.widget.Spinner;

class DialogWrapper_update {
    Spinner spinnerField = null;
    EditText valueField = null;
    RadioGroup radioField = null;
    View base = null;
    int spinnerSelected = -1;

    DialogWrapper_update(View base) {

        this.base = base;
        valueField = (EditText) base.findViewById(R.id.update_editText);
        spinnerField = (Spinner) base.findViewById(R.id.update_spinner);
        spinnerField.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            public void onItemSelected(AdapterView<?> arg0, View view1, int pos, long id) {
                spinnerSelected = pos;
            }

            public void onNothingSelected(AdapterView<?> arg1) {
                // Nothing
            }
        });
        radioField = (RadioGroup) base.findViewById(R.id.update_radioGroup);


    }

    int getSpinner() {
        return getSpinnerField();
    }

    String getValue() {
        String ret;
        if (spinnerSelected == 0)
            ret = "\"" + getValueField().getText().toString() + "\"";
        else ret = getValueField().getText().toString();
        return ret;
    }

    int getRadio() {
        return getRadioField();
    }

    private int getRadioField() {
        if (radioField == null) return -1;
        return radioField.getCheckedRadioButtonId();
    }

    private int getSpinnerField() {
        if (spinnerField == null) {
            return -1;
        }
        return spinnerSelected;
    }

    private EditText getValueField() {
        if (valueField == null) {
            valueField = (EditText) base.findViewById(R.id.value);

        }
        return valueField;
    }
}
