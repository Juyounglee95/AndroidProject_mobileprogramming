package com.example.user.databaseexample;

import android.os.StrictMode;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.provider.BaseColumns;

public final class DataBaseExampleContract{
    public DataBaseExampleContract(){}

    public static double GRAVITY_DEATH_STAR_I = 3.14159;
    public static double GRAVITY_EARTH = 9.80665;
    public static double GRAVITY_MARS= 3.71;
    public static double GRAVITY_MOON = 1.6;
    public static double GRAVITY_SUN = 275;

    public static abstract class ConstantEntry implements BaseColumns{
        public static final String TABLE_NAME = "constants";
        public static final String COLUMN_NAME_TITLE = "title";
        public static final String COLUMN_NAME_VALUE = "value";
    }
}