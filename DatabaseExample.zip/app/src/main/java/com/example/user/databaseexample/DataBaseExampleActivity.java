package com.example.user.databaseexample;

import android.app.AlertDialog;
import android.app.ListActivity;
import android.content.ContentValues;
import android.content.DialogInterface;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.ContextMenu;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListAdapter;
import android.widget.SimpleCursorAdapter;
import android.widget.Spinner;

import com.example.user.databaseexample.DataBaseExampleContract.ConstantEntry;


public class DataBaseExampleActivity extends ListActivity{
    private static final int ADD_ID = Menu.FIRST+1;
    private static final int DELETE_ID = Menu.FIRST+3;
    private static final int CLOSE_ID = Menu.FIRST+4;
    private static final int UPDATE_ID = Menu.FIRST+5;
    private SQLiteDatabase db = null;
    private Cursor constantsCursor = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        db = (new DataBaseHelper(this)).getWritableDatabase();
        constantsCursor = db.rawQuery("SELECT " + ConstantEntry._ID + ", " + ConstantEntry.COLUMN_NAME_TITLE + ", " + ConstantEntry.COLUMN_NAME_VALUE + " FROM " + ConstantEntry.TABLE_NAME + " ORDER BY " + ConstantEntry.COLUMN_NAME_TITLE, null);
        ListAdapter adapter = new SimpleCursorAdapter(this, R.layout.row, constantsCursor, new String[] {ConstantEntry.COLUMN_NAME_TITLE, ConstantEntry.COLUMN_NAME_VALUE}, new int[] {R.id.title, R.id.value},0);

        setListAdapter(adapter);
        registerForContextMenu(getListView());
    }

    public void onDestroy() {
        super.onDestroy();
        constantsCursor.close();
        db.close();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        //Inflate the menu; this adds items to the action bar if it is present.
        menu.add(Menu.NONE,ADD_ID,Menu.NONE,"Add").setIcon(R.mipmap.ic_launcher).setAlphabeticShortcut('a');
        menu.add(Menu.NONE,CLOSE_ID,Menu.NONE,"Close").setIcon(R.mipmap.ic_launcher).setAlphabeticShortcut('c');
        menu.add(Menu.NONE,UPDATE_ID,Menu.NONE,"Update").setIcon(R.mipmap.ic_launcher).setAlphabeticShortcut('d');
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();

        switch(id) {
            case ADD_ID:
                add();
                return true;
            case UPDATE_ID:
                update();
                return true;
            case CLOSE_ID:
                finish();
                return true;
        }
        return super.onOptionsItemSelected(item);
    }

    private void add() {
        LayoutInflater inflater = LayoutInflater.from(this);
        View addView = inflater.inflate(R.layout.add_edit, null);
        final DialogWrapper wrapper = new DialogWrapper(addView);

        new AlertDialog.Builder(this).setTitle(R.string.add_title).setView(addView).setPositiveButton(R.string.ok, new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int whichButton) {
                processAdd(wrapper);
            }
        })
                .setNegativeButton(R.string.cancel, new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int whichButton) {
                        // ignore
                    }
                }).show();
    }

    private void processAdd(DialogWrapper wrapper) {
        ContentValues values = new ContentValues(2);

        values.put(ConstantEntry.COLUMN_NAME_TITLE, wrapper.getTitle());
        values.put(ConstantEntry.COLUMN_NAME_VALUE, wrapper.getValue());
        db.insert(ConstantEntry.TABLE_NAME, ConstantEntry.COLUMN_NAME_TITLE, values);
        constantsCursor = db.rawQuery("SELECT " + ConstantEntry._ID + ", " + ConstantEntry.COLUMN_NAME_TITLE + ", " + ConstantEntry.COLUMN_NAME_VALUE + " FROM " + ConstantEntry.TABLE_NAME + " ORDER BY " + ConstantEntry.COLUMN_NAME_TITLE, null);

        ListAdapter adapter = new SimpleCursorAdapter(this, R.layout.row, constantsCursor, new String[] {ConstantEntry.COLUMN_NAME_TITLE, ConstantEntry.COLUMN_NAME_VALUE}, new int[] {R.id.title, R.id.value},0);
        setListAdapter(adapter);
        registerForContextMenu(getListView());
    }

    public boolean onContextItemSelected(MenuItem item){
        switch(item.getItemId()){
            case DELETE_ID:
                AdapterView.AdapterContextMenuInfo info=
                        (AdapterView.AdapterContextMenuInfo)item.getMenuInfo();
                delete(info.id);
                return true;

        }
        return super.onOptionsItemSelected(item);


    }
    private void update(){
        LayoutInflater inflater=LayoutInflater.from(this);
        View updateView=inflater.inflate(R.layout.update_edit, null);
        final DialogWrapper_update wrapper=new DialogWrapper_update(updateView);

        Spinner s =(Spinner)updateView.findViewById(R.id.update_spinner);
        String array_spinner[]=new String[2];
        array_spinner[0]=ConstantEntry.COLUMN_NAME_TITLE;
        array_spinner[1]=ConstantEntry.COLUMN_NAME_VALUE;
        ArrayAdapter adapter = new ArrayAdapter(updateView.getContext(),android.R.layout.simple_spinner_item,array_spinner);
        s.setAdapter(adapter);

        new AlertDialog.Builder(this).setTitle(R.string.update_title).setView(updateView).setPositiveButton(R.string.ok, new DialogInterface.OnClickListener(){
            public void onClick(DialogInterface dialog, int whichButton){
                processUpdate(wrapper);
            }
        }).setNegativeButton(R.string.cancel,new DialogInterface.OnClickListener(){
            public void onClick(DialogInterface dialog, int whichButton){
                //ignore
            }
        }).show();



    }
    private void processUpdate(DialogWrapper_update wrapper){
        String whereclause;
        String operator;
        if(wrapper.getSpinner()==0){
            whereclause=ConstantEntry.COLUMN_NAME_TITLE;
        }else whereclause=ConstantEntry.COLUMN_NAME_VALUE;
        switch (wrapper.getRadio()){
            case R.id.update_radio0:
                operator=">"; break;
            case R.id.update_radio1:
                operator="<"; break;
            case R.id.update_radio2:
                operator="="; break;
            default:
                operator=">";
        }

        constantsCursor = db.rawQuery("SELECT "+ ConstantEntry._ID+", "+ConstantEntry.COLUMN_NAME_TITLE+", "+ ConstantEntry.COLUMN_NAME_VALUE+" FROM "+ConstantEntry.TABLE_NAME+" WHERE "+ whereclause+" "+operator+" "+wrapper.getValue()+" ORDER BY "+ConstantEntry.COLUMN_NAME_TITLE, null);
        ListAdapter adapter= new SimpleCursorAdapter(this, R.layout.row, constantsCursor, new String[]{ConstantEntry.COLUMN_NAME_TITLE, ConstantEntry.COLUMN_NAME_VALUE},
                new int[]{R.id.title, R.id.value},0);

        setListAdapter(adapter);
        registerForContextMenu(getListView());
    }

    public void onCreateContextMenu(ContextMenu menu , View v, ContextMenu.ContextMenuInfo menuInfo)
    {
        menu.add(Menu.NONE, DELETE_ID, Menu.NONE,"Delete")
                .setIcon(R.mipmap.ic_launcher)
                .setAlphabeticShortcut('d');

    }

    private void delete(final long rowId){

        if(rowId>0){
            new AlertDialog.Builder(this)
                    .setTitle(R.string.delete_title)
                    .setPositiveButton(R.string.ok, new DialogInterface.OnClickListener(){
                        public void onClick(DialogInterface dialog, int whichButton){
                            processDelete(rowId);
                        }
                    })
                    .setNegativeButton(R.string.cancel, new DialogInterface.OnClickListener(){
                        public void onClick(DialogInterface dialog, int whichButton){
                        }
                    })
                    .show();
        }
    }
    private void processDelete(long rowId){

        String[] args={String.valueOf(rowId)};
        db.delete(ConstantEntry.TABLE_NAME, "_ID=?", args);
        constantsCursor = db.rawQuery("SELECT "+ConstantEntry._ID+", "+ ConstantEntry.COLUMN_NAME_TITLE+", "+ ConstantEntry.COLUMN_NAME_VALUE+" FROM "+ ConstantEntry.TABLE_NAME+" ORDER BY " + ConstantEntry.COLUMN_NAME_TITLE, null);
        ListAdapter adapter = new SimpleCursorAdapter(this, R.layout.row, constantsCursor,
                new String[] {ConstantEntry.COLUMN_NAME_TITLE, ConstantEntry.COLUMN_NAME_VALUE},
                new int[] {R.id.title, R.id.value}, 0);

        setListAdapter(adapter);
        registerForContextMenu(getListView());
    }
}