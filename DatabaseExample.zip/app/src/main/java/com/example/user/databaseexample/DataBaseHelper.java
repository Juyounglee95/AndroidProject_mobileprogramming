package com.example.user.databaseexample;

/**
 * Created by user on 2017-10-11.
 */

import android.content.ContentValues;
import android.content.Context;
import android.database.ContentObservable;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import com.example.user.databaseexample.DataBaseExampleContract.ConstantEntry;

public class DataBaseHelper extends SQLiteOpenHelper{
    public static final int DATABASE_VERSION=1;
    public static final String DATABASE_NAME = "db";

    private static final String TEXT_TYPE = " TEXT";
    private static final String REAL_TYPE = " REAL";
    private static final String COMMA_SEP = " ,";
    private static final String SQL_CREATE_ENTRIES = "CREATE TABLE "+ConstantEntry.TABLE_NAME+" ("+ConstantEntry._ID+" INTEGER PRIMARY KEY,"+ConstantEntry.COLUMN_NAME_TITLE + TEXT_TYPE + COMMA_SEP + ConstantEntry.COLUMN_NAME_VALUE + REAL_TYPE +" )";
    private static final String SQL_DELETE_ENTRIES = "DROP TABLE IF EXISTS "+ConstantEntry.TABLE_NAME;

    public DataBaseHelper(Context context){
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion){
        // This database is only a cache for online data, so its upgrade policy is to simply to discard the data and start over
        db.execSQL(SQL_DELETE_ENTRIES);
        onCreate(db);

    }

    @Override
    public void onCreate(SQLiteDatabase db){
        // TODO Auto-generated method stub
        db.execSQL(SQL_CREATE_ENTRIES);

        //Initiate the table with five rows
        ContentValues cv = new ContentValues();

        cv.put(ConstantEntry.COLUMN_NAME_TITLE,"Gravity, Death Star I");
        cv.put(ConstantEntry.COLUMN_NAME_VALUE,DataBaseExampleContract.GRAVITY_DEATH_STAR_I);
        db.insert(ConstantEntry.TABLE_NAME,ConstantEntry.COLUMN_NAME_TITLE,cv);

        cv.put(ConstantEntry.COLUMN_NAME_TITLE,"Gravity, Earth");
        cv.put(ConstantEntry.COLUMN_NAME_VALUE,DataBaseExampleContract.GRAVITY_EARTH);
        db.insert(ConstantEntry.TABLE_NAME,ConstantEntry.COLUMN_NAME_TITLE,cv);

        cv.put(ConstantEntry.COLUMN_NAME_TITLE,"Gravity, Mars");
        cv.put(ConstantEntry.COLUMN_NAME_VALUE,DataBaseExampleContract.GRAVITY_MARS);
        db.insert(ConstantEntry.TABLE_NAME,ConstantEntry.COLUMN_NAME_TITLE,cv);

        cv.put(ConstantEntry.COLUMN_NAME_TITLE,"Gravity, Moon");
        cv.put(ConstantEntry.COLUMN_NAME_VALUE,DataBaseExampleContract.GRAVITY_MOON);
        db.insert(ConstantEntry.TABLE_NAME,ConstantEntry.COLUMN_NAME_TITLE,cv);

        cv.put(ConstantEntry.COLUMN_NAME_TITLE,"Gravity, Sun");
        cv.put(ConstantEntry.COLUMN_NAME_VALUE,DataBaseExampleContract.GRAVITY_SUN);
        db.insert(ConstantEntry.TABLE_NAME,ConstantEntry.COLUMN_NAME_TITLE,cv);
    }
}