package com.example.user.intentfilterexample1;

import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.util.List;

public class MainActivity extends Activity {
    public final int CALLER_REQUEST =1;
    public static final String MY_ACTION ="com.example.user.intentfilterexample1.MainActivity";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void onClick(View v){
        EditText number1 = (EditText)findViewById(R.id.firstnumber_editText);
        EditText number2 = (EditText)findViewById(R.id.secondnumber_editText);

        try{
            int n1 = Integer.parseInt(number1. getText().toString());
            int n2 = Integer.parseInt(number2. getText().toString());


        }catch(Exception e){
            Toast.makeText(v.getContext(), "Error!", Toast.LENGTH_SHORT).show();
            return;

        }
        Intent intent = new Intent(com.example.user.intentfilterexample1.MainActivity.MY_ACTION);

        intent.putExtra("number1", number1.getText().toString());
        intent.putExtra("number2", number2.getText().toString());

        PackageManager packageManager = getPackageManager();
        List<ResolveInfo> activities = packageManager.queryIntentActivities(intent, 0);
        if(activities.size()>0){
            startActivityForResult(intent, CALLER_REQUEST);
        }
    }
    protected void onActivityResult(int requestCode, int resultCode, Intent data){
        if(requestCode ==CALLER_REQUEST){
            if(resultCode== RESULT_OK){
                String result = data.getExtras().getString("sum");
                TextView updated = (TextView)findViewById(R.id.textView2);
                updated.setText(result);
            }
        }
    }
}

