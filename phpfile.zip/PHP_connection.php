<?php
$con=mysqli_connect("localhost","root","","artfolio");
if(mysqli_connect_errno($con))
{
	echo "Failed to connect to MySQL: " .mysqli_connect_error();
}
mysqli_set_charset($con, "utf8");
$res = mysqli_query($con, "select * from user");
$result = array();
while($row = mysqli_fetch_array($res)){
	array_push($result, array('Name'=>$row[1], 'ID'=>$row[2], 'PW'=>$row[3]));
}
echo json_encode(array("result"=>$result));
mysqli_close($con);
?>