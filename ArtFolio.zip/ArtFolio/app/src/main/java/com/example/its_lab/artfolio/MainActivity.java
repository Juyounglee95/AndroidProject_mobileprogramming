package com.example.its_lab.artfolio;

import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.EditText;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.SimpleAdapter;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;

public class MainActivity extends AppCompatActivity {

    String myJSON;

    private static final String TAG_RESULT="result";
    private static final String TAG_NAME="Name";
    private static final String TAG_ID="ID";
    private static final String TAG_PW="PW";

    JSONArray user = null;

    ArrayList<HashMap<String,String >> userList;
    ListView list;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        list =(ListView)findViewById(R.id.listView);
        userList = new ArrayList<HashMap<String, String>>();
        getData("http://192.168.0.12/PHP_connection.php");
    }
    protected void showList(){

        try{
            JSONObject jsonObject = new JSONObject(myJSON);
            user = jsonObject.getJSONArray(TAG_RESULT);

                for(int i =0; i<user.length();i++){
                JSONObject jsonObj = user.getJSONObject(i);
                String name = jsonObj.getString(TAG_NAME);
                String id = jsonObj.getString(TAG_ID);
                String pw = jsonObj.getString(TAG_PW);

                HashMap<String, String> users = new HashMap<String, String>();

                users.put(TAG_NAME, name);
                users.put(TAG_ID, id);
                users.put(TAG_PW, pw);

                userList.add(users);

            }

            ListAdapter adapter = new SimpleAdapter(
                    MainActivity.this, userList, R.layout.list_item,
                    new String[]{TAG_NAME, TAG_ID, TAG_PW},
                    new int[]{R.id.name, R.id.id, R.id.pw}
            );
            list.setAdapter(adapter);

        }catch (JSONException e){
            e.printStackTrace();
        }
    }

    public void getData(String url){
        class getDataJson extends AsyncTask<String, Void, String>{
            protected String doInBackground(String... params){
                String uri = params[0];
                BufferedReader bufferedReader = null;
                try {
                    URL url = new URL(uri);
                    HttpURLConnection con = (HttpURLConnection) url.openConnection();
                    StringBuilder stringBuilder = new StringBuilder();
                    bufferedReader = new BufferedReader(new InputStreamReader(con.getInputStream()));
                    String json;
                    while((json = bufferedReader.readLine())!= null){
                        stringBuilder.append(json+"\n");

                    }
                    return stringBuilder.toString().trim();
                }catch (Exception e){
                    return null;
                }
            }

            protected void onPostExecute(String  result){
                myJSON = result;
                showList();
            }
        }
        getDataJson getdj = new getDataJson();
        getdj.execute(url);
    }
}
