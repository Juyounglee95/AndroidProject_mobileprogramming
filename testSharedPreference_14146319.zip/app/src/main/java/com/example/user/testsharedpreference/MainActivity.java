package com.example.user.testsharedpreference;

import android.content.Context;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
    public void saveMessage(View view){
        SharedPreferences sharedPref = this.getPreferences(Context.MODE_PRIVATE);
        SharedPreferences.Editor editor=sharedPref.edit();
        EditText editText1=(EditText)findViewById(R.id.editText1);
        EditText editText2 = (EditText)findViewById(R.id.editText2);
        String string_id =editText1.getText().toString();
        String string_password= editText2.getText().toString();

        editor.putString(getString(R.string.string_id), string_id);
        editor.putString(getString(R.string.string_password), string_password);
        editor.commit();
        Toast.makeText(this, "ID/Password Saved", Toast.LENGTH_SHORT).show();
    }
    public void loadMessage(View view){
        SharedPreferences sharedPref= this.getPreferences(Context.MODE_PRIVATE);
        EditText editText1=(EditText)findViewById(R.id.editText1);
        EditText editText2 = (EditText)findViewById(R.id.editText2);
        String string_id, def_strid="Empty()";
        String string_password, def_strpasswd="Empty_Passwd()";

        string_id=sharedPref.getString(getString(R.string.string_id),def_strid);
        string_password=sharedPref.getString(getString(R.string.string_password),def_strpasswd);

        editText1.setText(string_id);
        editText2.setText(string_password);
        Toast.makeText(this, "Id/Password Loaded", Toast.LENGTH_SHORT).show();

    }
}
